<?php 
include("header.php")
?>
<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title>Index</title>
 </head>
 <body>
     
	
	 
          <div class="container mt-5">
               <div class="row">
			   <div class="col-lg-3">
			   <form action="manage_cart.php" method="POST">
			   <div class="card">
			    <img src="pics/24hr/image12.jpeg" class="card-img-top">
	               <div class="card-body text-center">
	                  <h5 class="card-title">Ergonomic 24-hr Office Chair</h5>
	                     <p class="card-text">Price: Rs.1000</p>
	                       <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
			                 <input type="hidden" name="Item_Name" value="Ergonomic 24-hr Office Chair">
				            <input type="hidden" name="Price" value="1000">
	                          </div>
							  </div>
							    </form>
								</div>
								
								 
	
	                            <div class="col-lg-3">
		                         <form action="manage_cart.php" method="POST">
	                                   <div class="card">
	                                   <img src="pics/24hr/image18.jpeg" class="card-img-top">
	                                         <div class="card-body text-center">
	                                         <h5 class="card-title">24-hr Office Adjustable Height</h5>
	                                          <p class="card-text">Price: Rs.1400</p>
	                                          <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
			                                 <input type="hidden" name="Item_Name" value="24-hr Office Adjustable Height">
			                            	<input type="hidden" name="Price" value="1400">
	                                       </div>
										   </div>
 	                                      </form>
				                         </div>
	           
	  
			                       <div class="col-lg-3">
			                        <form action="manage_cart.php" method="POST">
	                                 <div class="card">
				                     <img src="pics/24hr/image32.jpeg" class="card-img-top">
	                                    <div class="card-body text-center">
	                                         <h5 class="card-title">Seating Apollo 24-hr Office Stool, Black</h5>
	                                           <p class="card-text">Price: Rs.3750</p>
	                                                <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
			                                        <input type="hidden" name="Item_Name" value="Seating Apollo 24-hr Office Stool, Black">
				                                      <input type="hidden" name="Price" value="3750">
	                                                  </div>
						                              </div>
			                                          </form>
										              </div>
				

		    </div>
          </div>
        </div>
      </body>
   </html>
   