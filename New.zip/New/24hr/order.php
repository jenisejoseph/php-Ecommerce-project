<?php
	   if(isset($_POST['Make Purchase']))
	  {
		  foreach($_SESSION['order'] as $key => $value)
		  {
			  if($value['order']==$_POST['order'])
			  {
			  unset($_SESSION['order'][$key]);
			  $_SESSION['order']=array_values($_SESSION['order']);
			  echo"<script>
			  alert('order placed');
			  window.location.href='my_cart.php';
			  </script>";
			  }
		  }
	  }
	
	?>