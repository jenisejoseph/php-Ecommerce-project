<!DOCTYPE html>
<html lang="en">
<?php require_once('popup.php'); ?>
<?php require_once('cd.php'); ?>
<head>
<title>Mywebsite  <?php echo "Office Chairs"; ?></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
/* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

/* Style the header */
.header {
  padding: 80px;
  text-align: center;
  background: #1abc9c;
  color: white;
   
}

/* Increase the font size of the h1 element */
.header h1 {
  font-size: 40px;
}

/* Style the top navigation bar */
.navbar {
  overflow: hidden;
  background-color: #333;
}

/* Style the navigation bar links */
.navbar a {
  float: left;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 20px;
  text-decoration: none;
}

/* Right-aligned link */
.navbar a.right {
  float: right;
}

/* Change color on hover */
.navbar a:hover {
  background-color: #ddd;
  color: black;
}

/* Column container */
.row {  
  display: flex;
  flex-wrap: wrap;
}

/* Create two unequal columns that sits next to each other */
/* Sidebar/left column */
.side {
  flex: 30%;
  background-color: #f1f1f1;
  padding: 20px;

  }

/* Main column */
.main {   
  flex: 70%;
  background-color: white;
  padding: 20px;
}

/* Fake image, just for this example */
.fakeimg {
  background-color: #aaa;
  width: 100%;
  padding: 20px;
}

.center {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 90px;
  border: white; 
}

.mybtn {
  display: none; /* Hidden by default */
  position: fixed; /* Fixed/sticky position */
  bottom: 20px; /* Place the button at the bottom of the page */
  right: 30px; /* Place the button 30px from the right */
  z-index: 99; /* Make sure it does not overlap */
  border: none; /* Remove borders */
  outline: none; /* Remove outline */
  background-color: red; /* Set a background color */
  color: white; /* Text color */
  cursor: pointer; /* Add a mouse pointer on hover */
  padding: 15px; /* Some padding */
  border-radius: 10px; /* Rounded corners */
  font-size: 18px; /* Increase font size */
}

.mybtn:hover {
  background-color: #555; /* Add a dark-grey background on hover */
}


/* Footer */
.footer {
  padding: 20px;
  text-align: center;
  background: #ddd;
}

/* Responsive layout - when the screen is less than 700px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 700px) {
  .row {   
    flex-direction: column;
  }
}

/* Responsive layout - when the screen is less than 400px wide, make the navigation links stack on top of each other instead of next to each other */
@media screen and (max-width: 400px) {
  .navbar a {
    float: none;
    width:100%;
  }
}


</style>
</head>
<body>

<div class="header">
  <h1>Office Chairs</h1>
  <p>A website created by me.</p>
</div>

<div class="row">
  <div class="side">
    <h2>Description</h2>
	
    <div class="image" style="height:200px;">
	  <!-- Slide Show -->
<section>
 <img class="mySlides" src="pics/drafting/image0.jpeg"
  style="width:32%">
  <img class="mySlides" src="pics/drafting/image1.jpeg"
  style="width:32%">
  <img class="mySlides" src="pics/drafting/image2.jpeg"
  style="width:32%">
</section>
	
	</div>
	
    <?php 
	echo "Office Chairs located at ADDRESS : Beautiful Street side of Sun-city River,
	Pune-411015, Maharashtra, India."?>
<br>
<?php
 echo "We are in Top Most Suppliers of in India with wide range of Products and Services to cater to the varied Requirements of Customers.
Goal is to Provide Manufacturing & Repairing of All Kinds of Chairs.";?>
    <br>
	<br>
	
	 <?php 
	echo "Hours of Operation";?>
	<br>
	<?php
	echo "Monday 9:00 am - 9:00 pm : Open";?>
	<a href="contact.php">View All</a>
	<br>
	<br>
    <div class="fakeimg" style="height:50px;">Top Most Products </div><br>
    <div class="fakeimg" style="height:80px;"><a href="login.php">Drafting Chairs</a>
	<a href="login.php">Executive Chairs</a><br>
      <a href="login.php">Leather Chairs</a>
	  <a href="login.php">Mesh Chairs</a><br>
 </div><br>
    <div class="fakeimg" style="height:100px;">
    <a href="login.php">Big and Tall Chairs</a><br>
    <a href="login.php">Petite and Small Chairs</a><br>
	<a href="login.php">24-hr Office Chair</a><br>
	<a href="login.php"> Conference Chair</a></div>
  </div>
  
  <div class="main">
    <h2>WELCOME To Our Website</h2>
    <h5></h5>
	 
    <?php
	echo "We are in Top Most Suppliers of in India with wide range of Products and 
	Services to cater to the varied Requirements of Customers.
	
	Goal is to Provide Manufacturing & Repairing of All Kinds of Chairs.";?>
	<br>
	<br>
	
	<?php
	echo "Provides Top Service in the following Categories:
(Executive Chair, Visitor Chair, Furniture Dealers, Wheel Chair Dealers, Chair Repair & Services, Computer Chair, Class Chair, Office Chair Repair & Services, Wheel Chair Manufacturers, Office Chair Dealers, Chair Dealers, Revolving Chair Dealers,etc).
You can Buy in bulk from us for the best quality products and service.";?>
  <br>
<form method="get" action="details.php">
<div class="center">
    <button type="submit"><?php echo "In Detail";?></button></div>
</form>


    <h2><?php echo "HERE ARE TOP MOST PRODUCTS";?></h2>
    <h5>Title description, Sep 2, 2017</h5>

<?php
echo '
<html>
<img src="pics/drafting/image0.jpeg" width="200" height="350px"/>
<img src="pics/mesh/image35.jpeg" width="200" height="350px"/>
<img src="pics/drafting/image1.jpeg" width="200" height="350px"/>
<br>
<br>
<br>
<img src="pics/drafting/image2.jpeg" width="200" height="350px"/>
<img src="pics/mesh/image36.jpeg" width="200" height="350px"/>
<img src="pics/drafting/image3.jpeg" width="200" height="350px"/>

<br>
</html>
';
?>
<form method="get" action="login.php">
<div class="center">
    <button type="submit"><?php echo "See More"; ?></button></div>
</form>
<br> 

</div>
</div>

<?php require_once('footer.php'); ?>
<script>
// Automatic Slideshow - change image every 3 seconds
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}
  x[myIndex-1].style.display = "block";
  setTimeout(carousel, 3000);
}
</script>

</body>
</html>