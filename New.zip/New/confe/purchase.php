<?php  
session_start();
  
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "blog";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
//echo "connected";
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
//echo " not connected";
}
//session_start();
//$conn=mysqli_connect("localhost","root","");

//if(mysqli_connect_erorr()){
	//echo"<script>
	//alert('cannot connect to database');
	//window.location.href='my_cart.php';
	//</script>";
	//exit();}
	

if($_SERVER["REQUEST_METHOD"]=="POST")
{
	if(isset($_POST['purchase']))
	{
		//$query1="INSERT INTO 'order_manager'('Full_Name','Phone_No','Address','Pay_Mode') VALUES ('$_POST[full_name]','$_POST[phone_no]','$_POST[address]','$_POST[pay_mode]','[value-1]','[value-2]','[value-3]','[value-4]','[value-5]')";
        //if(mysqli_query($conn,$query1))
		
        $query1=" INSERT INTO order_manager(Full_Name, Phone_No, Address, Pay_Mode) 
		VALUES ('$_POST[full_name]','$_POST[phone_no]','$_POST[address]','$_POST[pay_mode]')";
		
		if(mysqli_query($conn,$query1))
		{
			$Order_Id=mysqli_insert_id($conn);
			$query2="INSERT INTO `user_order`(`Order_id`, `Item_Name`, `Price`, `Quantity`) VALUES (?,?,?,?)";
		     $stmt=mysqli_prepare($conn,$query2);
			 if($stmt)
			 {
				mysqli_stmt_bind_param($stmt,"isii",$Order_Id,$Item_Name,$Price,$Quantity);
				foreach($_SESSION['cart'] as $key => $values)
				{
					$Item_Name=$values['Item_Name'];
					$Price=$values['Price'];
					$Quantity=$values['Quantity'];
					mysqli_stmt_execute($stmt);
					
				}
				unset($_SESSION['cart']);
				echo"<script>
	         alert('Order placed');
	         window.location.href='confe1.php';
	        </script>";
		}	 
			 
			else
		{
			echo"<script>
	         alert('SQL Query Prepared Error');
	         window.location.href='confe1.php';
	        </script>";
		}	 
		}
		else
		{
			echo"<script>
	         alert('SQL Error');
	         window.location.href='confe1.php';
	        </script>";
		}	
}
}

?>