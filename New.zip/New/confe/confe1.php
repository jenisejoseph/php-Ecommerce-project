<?php 
include("header.php")
?>
<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title>Index</title>
 </head>
 <body>
     
	
	 
          <div class="container mt-5">
               <div class="row">
			   <div class="col-lg-3">
			   <form action="manage_cart.php" method="POST">
			   <div class="card">
			    <img src="pics/conf/image24.jpeg" class="card-img-top">
	               <div class="card-body text-center">
	                  <h5 class="card-title">Ergonomic Conference Chair with Arms</h5>
	                     <p class="card-text">Price: Rs.5000</p>
	                       <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
			                 <input type="hidden" name="Item_Name" value="Ergonomic Conference Chair with Arms">
				            <input type="hidden" name="Price" value="5000">
	                          </div>
							  </div>
							    </form>
								</div>
								
								 
	
	                            <div class="col-lg-3">
		                         <form action="manage_cart.php" method="POST">
	                                   <div class="card">
	                                   <img src="pics/conf/image26.jpeg" class="card-img-top">
	                                         <div class="card-body text-center">
	                                         <h5 class="card-title">Home Conference Office Adjustable Height</h5>
	                                          <p class="card-text">Price: Rs.4000</p>
	                                          <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
			                                 <input type="hidden" name="Item_Name" value="Home Conference Office Adjustable Height">
			                            	<input type="hidden" name="Price" value="4000">
	                                       </div>
										   </div>
 	                                      </form>
				                         </div>
	           
	  
			                       <div class="col-lg-3">
			                        <form action="manage_cart.php" method="POST">
	                                 <div class="card">
				                     <img src="pics/conf/image28.jpeg" class="card-img-top">
	                                    <div class="card-body text-center">
	                                         <h5 class="card-title">Seating Apollo Conference with Drafting Stool, Black</h5>
	                                           <p class="card-text">Price: Rs.3050</p>
	                                                <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
			                                        <input type="hidden" name="Item_Name" value="Seating Apollo Conference with Drafting Stool, Black">
				                                      <input type="hidden" name="Price" value="3050">
	                                                  </div>
						                              </div>
			                                          </form>
										              </div>
				
		    </div>
          </div>
        </div>
      </body>
   </html>
   