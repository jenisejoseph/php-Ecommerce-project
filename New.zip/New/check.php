<?php

if (!isset($_SESSION['userid-email'])) 
{
	
	header('Location:login.php');

}

?>