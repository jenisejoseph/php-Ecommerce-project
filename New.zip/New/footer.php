<html>
<style>
/* Footer */
.footer {
  padding: 20px;
  text-align: center;
  background:#808080;
}

/* Responsive layout - when the screen is less than 700px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 700px) {
  .row {   
    flex-direction: column;
  }
}

/* Responsive layout - when the screen is less than 400px wide, make the navigation links stack on top of each other instead of next to each other */
@media screen and (max-width: 400px) {
  .navbar a {
    float: none;
    width:100%;
  }
}
</style>



<div class="footer">
  <h2></h2>
   <?php  
	echo "Contact Number : 1234567890";?>
<br>
<?php echo "Email I'd : jenise25@gmail.com ";?>
	
<form method="get" action="#">
<div class="center">
    <button type="submit"><?php echo "HOME"; ?></button></div>
</form>  

    <div class="center_footer"> 
      <img src="pics/logo.jpg" alt="" width="100" height="60"/>
    </div>
    <div class="center_footer"> 
       All Rights Reserved 2021<br/>
       <img src="images/payment.gif" alt="" />
    
    <div class="right_footer"> 
       
       <a href="details.php">About Us</a> 
       <a href="contact.php">Contact us</a> <br>
	   <br>
	   <?php echo "Go To Top : ";?>
<a href "index.php"><width="300" height="300px">Scroll Up</a>
<br>
</div>
    </div>
  </div>
  </html>