<?php 
//somecode 
?> 
<!DOCTYPE html> 
<html> 
<?php require_once('cd.php'); ?>
<body> 
<img src='photos/pic14.jpg' /> 
</body> 
</html> 