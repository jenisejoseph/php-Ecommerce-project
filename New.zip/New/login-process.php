<?php 

session_start();

include 'func.php';

$conn = db();

$user_email = $_POST['email'];

$user_password = $_POST['password'];

$sql = " SELECT * FROM users WHERE email = '".$user_email."' AND password = '".$user_password."' ";

$query = $conn->query($sql);

$result = $query->num_rows;

$name = $query->fetch_all(1)[0];

// dd($name);

if ($result>0) 
{
	
	if (isset($_POST['btn']) && $_POST['btn'] == 1) 
	{
	
		$_SESSION['userid-email'] = $user_email;

		$_SESSION['user_name'] = $name['firstname'].' '.$name['lastname'];

		$_SESSION['user_id'] = $name['id'];

		header('Location:menuu.php');

	}
	else
	{

		$_SESSION['userid-email'] = $user_email;	

		$_SESSION['user_name'] = $name['firstname'].' '.$name['lastname'];

		$_SESSION['user_id'] = $name['id'];	

		header('Location:menuu.php');

	}

}
else
{

	header('Location:login.php?err=1');

}



?>