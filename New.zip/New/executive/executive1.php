<?php 
include("header.php")
?>
<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title>Index</title>
 </head>
 <body>
     
	
	 
          <div class="container mt-5">
               <div class="row">
			   <div class="col-lg-3">
			   <form action="manage_cart.php" method="POST">
			   <div class="card">
			    <img src="pics/executive/image17.jpeg" class="card-img-top">
	               <div class="card-body text-center">
	                  <h5 class="card-title">Ergonomic Executive Chair,<br>Tall Desk Chair with Arms</h5>
	                     <p class="card-text">Price: Rs.5000</p>
	                       <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
			                 <input type="hidden" name="Item_Name" value="Ergonomic Executive Chair,Tall Desk Chair with Arms">
				            <input type="hidden" name="Price" value="5000">
	                          </div>
							  </div>
							    </form>
								</div>
								
								 
	
	                            <div class="col-lg-3">
		                         <form action="manage_cart.php" method="POST">
	                                   <div class="card">
	                                   <img src="pics/executive/image20.jpeg" class="card-img-top">
	                                         <div class="card-body text-center">
	                                         <h5 class="card-title">Seating Apollo Executive with Drafting Stool, Black</h5>
	                                          <p class="card-text">Price: Rs.7600</p>
	                                          <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
			                                 <input type="hidden" name="Item_Name" value="Seating Apollo Executive Stool, Black">
			                            	<input type="hidden" name="Price" value="7600">
	                                       </div>
										   </div>
 	                                      </form>
				                         </div>
	           
	  
			                       <div class="col-lg-3">
			                        <form action="manage_cart.php" method="POST">
	                                 <div class="card">
				                     <img src="pics/executive/image21.jpeg" class="card-img-top">
	                                    <div class="card-body text-center">
	                                         <h5 class="card-title">Home Executive Office Adjustable Height</h5>
	                                           <p class="card-text">Price: Rs.3750</p>
	                                                <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
			                                        <input type="hidden" name="Item_Name" value="Home Executive Office Adjustable Height">
				                                      <input type="hidden" name="Price" value="3750">
	                                                  </div>
						                              </div>
			                                          </form>
										              </div>
				

                     		             <div class="col-lg-3"> 
			                                <form action="manage_cart.php" method="POST">
	                                        <div class="card">
				                               <img src="pics/executive/image22.jpeg" class="card-img-top">
	                                             <div class="card-body text-center">
	                                              <h5 class="card-title">Desk Adjustable Executive Stools with Backrest & Foot Rest</h5>
	                                              <p class="card-text">Price: Rs.7890</p>
	                                                   <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
			                                             <input type="hidden" name="Item_Name" value="Desk Adjustable Executive Stools with Backrest
														 & Foot Rest">
				                                              <input type="hidden" name="Price" value="7890">
	                                                            </div>
						                                        </div>
			                                                      </form>
							                            			</div>		
										
										 <div class="col-lg-3">
			                        <form action="manage_cart.php" method="POST">
	                                 <div class="card">
				                     <img src="pics/executive/image23.jpeg" class="card-img-top">
	                                    <div class="card-body text-center">
	                                         <h5 class="card-title">Shop Executive Stool Chair</h5>
	                                           <p class="card-text">Price: Rs.2000</p>
	                                                <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
			                                        <input type="hidden" name="Item_Name" value="Shop Executive Stool Chair">
				                                      <input type="hidden" name="Price" value="2000">
	                                                  </div>
						                              </div>
			                                          </form>
										              </div>
													  
											
										 <div class="col-lg-3">
			                        <form action="manage_cart.php" method="POST">
	                                 <div class="card">
				                     <img src="pics/executive/image25.jpeg" class="card-img-top">
	                                    <div class="card-body text-center">
	                                         <h5 class="card-title">Adjustable Executive Chrome Foot Ring, Adjustable Arms</h5>
	                                           <p class="card-text">Price: Rs.3000</p>
	                                                <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
			                                        <input type="hidden" name="Item_Name" value="Adjustable Executive Chrome Foot Ring, Adjustable Arms">
				                                      <input type="hidden" name="Price" value="3000">
	                                                  </div>
						                              </div>
			                                          </form>
										              </div>		  
										 
										 <div class="col-lg-3">
			                        <form action="manage_cart.php" method="POST">
	                                 <div class="card">
				                     <img src="pics/executive/image27.jpeg" class="card-img-top">
	                                    <div class="card-body text-center">
	                                         <h5 class="card-title">Office Desk Executive Chair with Foot Rest (Black)</h5>
	                                           <p class="card-text">Price: Rs.4500</p>
	                                                <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
			                                        <input type="hidden" name="Item_Name" value="Office Desk Executive Chair with Foot Rest (Black)">
				                                      <input type="hidden" name="Price" value="4500">
	                                                  </div>
						                              </div>
			                                          </form>
										              </div>

                                           <div class="col-lg-3">
			                        <form action="manage_cart.php" method="POST">
	                                 <div class="card">
				                     <img src="pics/executive/image29.jpeg" class="card-img-top">
	                                    <div class="card-body text-center">
	                                         <h5 class="card-title">Office Desk Executive Chair</h5>
	                                           <p class="card-text">Price: Rs.3000</p>
	                                                <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
			                                        <input type="hidden" name="Item_Name" value="Office Desk Executive Chair">
				                                      <input type="hidden" name="Price" value="3000">
	                                                  </div>
						                              </div>
			                                          </form>
										              </div>	

									
                                           <div class="col-lg-3">
			                        <form action="manage_cart.php" method="POST">
	                                 <div class="card">
				                     <img src="pics/executive/image33.jpeg" class="card-img-top">
	                                    <div class="card-body text-center">
	                                         <h5 class="card-title">Executive Chair </h5>
	                                           <p class="card-text">Price: Rs.3000</p>
	                                                <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
			                                        <input type="hidden" name="Item_Name" value="Executive Chair">
				                                      <input type="hidden" name="Price" value="3000">
	                                                  </div>
						                              </div>
			                                          </form>
										              </div>				  
	
		    </div>
          </div>
        </div>
      </body>
   </html>
   