<html lang="en">
<?php require_once('ij.php'); ?>
<head>
<title>Mywebsite  <?php echo "Electronics"; ?></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

/* Main column */
.main {   
  flex: 70%;
  background-color: #1abc9c;
  padding: 20px;
}
</style>
</head>
<body>
 <div class="main">
  <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">

 
    <h2>CONTACT INFORMATION</h2>
    <h5></h5>
    
	<?php echo "NAME : Jenise Joseph"; ?><br>
	<?php echo "NAME : Shravani Kadam"; ?><br>
	<br>
	<br>
	<?php echo "ADDRESS : Beautiful Street side of Sun-city River,
	Pune-411015, Maharashtra, India"; ?> <br>
	<br>
    <?php
 echo "Hours of Operation : "; ?><br>
 <br>
<?php echo "Monday : 9:00 am - 9:00 pm";?> <br>
<?php echo "Tuesday : 9:00 am - 9:00 pm";?> <br>
<?php echo "Wednesday : 9:00 am - 9:00 pm";?> <br>
<?php echo "Thursday : 9:00 am - 9:00 pm";?> <br>
<?php echo "Friday : 9:00 am - 9:00 pm";?> <br>
<?php echo "Saturday : 9:00 am - 9:00 pm";?> <br>
<?php echo "Sunday Closed";?>
    <br>
	<br>
	
</div>
</div>

<div class="footer">
  <h2></h2>
   <?php  
	echo "Contact Number : 91-1234567897.";?>
<br>
<?php echo "Email I'd : chairwebsite96@gmail.com ";?>
	
<form method="get" action="index.php">
<div class="center">
    <button type="submit"><?php echo "HOME"; ?></button></div>
</form>  
</div>

</body>
</html>