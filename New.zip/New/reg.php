<!DOCTYPE html>
<html>
<?php require_once('ef.php'); ?>
	<head>
	<style>
	

.double {border-style: double;}

body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
  background-color: #labc9c;
}

/* Style the body */
.body {
  padding: 80px;
  background-color: #1abc9c;
  color: white;
   
}

/* Main column */
.container {   
    background-color: #1abc9c;
  
 
}

/* Increase the font size of the h1 element */
.header h1 {
  font-size: 40px;
}

/* Style the top navigation bar */
.navbar {
  overflow: hidden;
  background-color: #333;
}

/* Change color on hover */
.navbar a:hover {
  background-color: #ddd;
  color: black;
}
</style>

		<title>New Registration</title>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
</head>	
	<body>
		
		<div class="container">
			<div class="col-md-6">
				<h1>Registration</h1>
				<form action="reg-process.php" method="POST">
					<div class="form-group">
						<label for="exampleInputEmail1">First Name</label>
						<input type="text" class="form-control" placeholder="First Name" name="firstname">
					</div>
					<div class="form-group">
						<label for="exampleInputPassword1">Last Name</label>
						<input type="text" class="form-control" placeholder="Last Name" name="lastname">
					</div>
					
					<div class="form-group">
						<label for="exampleInputPassword1">Email</label>
						<input type="text" class="form-control" placeholder="Email" name="email">
					</div>
					<div class="form-group">
						<label for="exampleInputPassword1">Password</label>
						<input type="password" class="form-control"  placeholder="Password" name="password">
					</div>
					<div class="form-group">
						<label for="exampleInputPassword1">Location</label>
						<input type="text" class="form-control" placeholder="Location" name="location">
					</div>
					<div class="form-group">
	                    <label for="birthDate">Date of Birth</label>
	                    <input type="date" class="form-control" name="birthdate">
	                 </div>
					<button type="submit" class="btn btn-default">Submit</button><br>
					<br>
					<br>
					<?php if (isset($_GET['err'])) {
							echo "Your username and password wrong";
						} ?>
				</form>
				
				<form method="get" action="signup.php">
<div class="left">
    <button type="submit"><?php echo "SIGN-UP AS ADMIN -> "; ?></button></div>
</form>
<br>
				
			</div>
		</div>
		
		 
		
		
	</body>
</html>