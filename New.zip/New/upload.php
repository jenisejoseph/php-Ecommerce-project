<html>
<?php
$eno=$_POST['eno'];
$ename=$_POST['ename'];
$salary=$_POST['salary'];
$designation=$_POST['designation'];
class Employee
{
	var $name, $rno, $year;
	public function acceptdata($name, $rno, $year)
	{
		$this->eno = $eno;
		$this->ename = $ename;
		$this->salary= $salary;
		$this->designation=$designation;
	}
	public function displaydata()
	{
		echo" employee number is $eno";
		echo"employee name is $ename";
		echo"employee salary is $salary";
		echo"employee designation is $designation ";
	}
}
?>
</html>