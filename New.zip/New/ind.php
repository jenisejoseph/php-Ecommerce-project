<!DOCTYPE html>
<html lang="en">

<head>
<title>Mywebsite  <?php echo "Electronics"; ?></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
/* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

/* Style the header */
.header {
  padding: 80px;
  text-align: center;
  background: #1abc9c;
  color: white;
   
}

/* Increase the font size of the h1 element */
.header h1 {
  font-size: 40px;
}

/* Style the top navigation bar */
.navbar {
  overflow: hidden;
  background-color: #333;
}

/* Style the navigation bar links */
.navbar a {
  float: left;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 20px;
  text-decoration: none;
}

/* Right-aligned link */
.navbar a.right {
  float: right;
}

/* Change color on hover */
.navbar a:hover {
  background-color: #ddd;
  color: black;
}

/* Column container */
.row {  
  display: flex;
  flex-wrap: wrap;
}

/* Create two unequal columns that sits next to each other */
/* Sidebar/left column */
.side {
  flex: 30%;
  background-color: #f1f1f1;
  padding: 20px;

  }

/* Main column */
.main {   
  flex: 70%;
  background-color: white;
  padding: 20px;
}

/* Fake image, just for this example */
.fakeimg {
  background-color: #aaa;
  width: 100%;
  padding: 20px;
}

.center {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 90px;
  border: white; 
}

.mybtn {
  display: none; /* Hidden by default */
  position: fixed; /* Fixed/sticky position */
  bottom: 20px; /* Place the button at the bottom of the page */
  right: 30px; /* Place the button 30px from the right */
  z-index: 99; /* Make sure it does not overlap */
  border: none; /* Remove borders */
  outline: none; /* Remove outline */
  background-color: red; /* Set a background color */
  color: white; /* Text color */
  cursor: pointer; /* Add a mouse pointer on hover */
  padding: 15px; /* Some padding */
  border-radius: 10px; /* Rounded corners */
  font-size: 18px; /* Increase font size */
}

.mybtn:hover {
  background-color: #555; /* Add a dark-grey background on hover */
}


/* Footer */
.footer {
  padding: 20px;
  text-align: center;
  background: #ddd;
}

/* Responsive layout - when the screen is less than 700px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 700px) {
  .row {   
    flex-direction: column;
  }
}

/* Responsive layout - when the screen is less than 400px wide, make the navigation links stack on top of each other instead of next to each other */
@media screen and (max-width: 400px) {
  .navbar a {
    float: none;
    width:100%;
  }
}
</style>
</head>
<body>
<div class="navbar">
  <a href="#">HOME</a>
  <a href="details.php">ABOUT US</a>
   <a href="seemore.php">PRODUCTS</a>
  <a href="contact.php">CONTACT</a>
  <a href="offers.php">OFFERS</a>
  <a href="new.php">New Release Products</a>
  <a href="login.php">Login</a>
  <a href="reg.php">Sign-Up</a>
  <a href="logout.php">Logout</a>
  
  <a href="#" class="right">Link</a>
</div>
<div class="header">
  <h1>Electronics</h1>
  <p>A website created by me.</p>

</div>

<div class="navbar">
  <a href="seemore.php">PRODUCTS</a>
  <a href="offers.php">OFFERS</a> 
  <a href="new.php">New Release Products</a>
  <a href="#" class="right">Link</a>
</div>

              <li><a href="details.php">About Us <span class="sr-only">(current)</span></a></li>

            

<div class="row">
  <div class="side">
    <h2>Description</h2>
	
    <h5>Photo:</h5>
    <div class="fakeimg" style="height:200px;">Image
	  <!-- Slide Show -->
<section>
 <img class="mySlides" src="pics/image0.jpeg"
  style="width:32%">
  <img class="mySlides" src="pics/image1.jpeg"
  style="width:32%">
  <img class="mySlides" src="pics/image2.jpeg"
  style="width:32%">
</section>
	
	</div>
	
    <?php 
	echo "Electronics located at Sr.No. 51, Plot No. 21, Maharana Pratap Chowk, Lane No. 10, Dhanori Road,
Bhairav Nagar, Pune- 411015, Maharashtra.;"?>
<br>
<?php
 echo "We are in Top Most Suppliers of in India with wide range of Products and Services to cater to the varied Requirements of Customers.
Goal is to Provide Manufacturing & Repairing of All Kinds of Chairs.";?>
    <br>
	<br>
	
	 <?php 
	echo "Hours of Operation";?>
	<br>
	<?php
	echo "Monday 9:00 am - 9:00 pm : Open";?>
	<a href="contact.php">View All</a>
	<br>
	<br>
	

	
    <p>Lorem ipsum dolor sit ame.</p>
    <div class="fakeimg" style="height:60px;">Image</div><br>
    <div class="fakeimg" style="height:60px;">Image</div><br>
    <div class="fakeimg" style="height:60px;">Image</div>
  </div>
  <div class="main">
    <h2>WELCOME TO 
	Electronics</h2>
    <h5></h5>
	 
    <?php
	echo "We are in Top Most Suppliers of in India with wide range of Products and 
	Services to cater to the varied Requirements of Customers.
	
	Goal is to Provide Manufacturing & Repairing of All Kinds of Chairs.";?>
	<br>
	<br>
	
	<?php
	echo "Provides Top Service in the following Categories:
(Executive Chair, Visitor Chair, Furniture Dealers, Wheel Chair Dealers, Chair Repair & Services, Computer Chair, Class Chair, Office Chair Repair & Services, Wheel Chair Manufacturers, Office Chair Dealers, Chair Dealers, Revolving Chair Dealers,etc).
You can Buy in bulk from us for the best quality products and service.";?>
  <br>
<form method="get" action="details.php">
<div class="center">
    <button type="submit"><?php echo "In Detail";?></button></div>
</form>


    <h2><?php echo "HERE ARE TOP MOST PRODUCTS";?></h2>
    <h5>Title description, Sep 2, 2017</h5>

	<?php
echo '
<html>
<img src="pics/image0.jpeg" width="270" height="400px"/>
<img src="pics/image35.jpeg" width="270" height="400px"/>
<img src="pics/image1.jpeg" width="270" height="400px"/>
<br>
<img src="pics/image2.jpeg" width="270" height="400px"/>
<img src="pics/image36.jpeg" width="270" height="400px"/>
<img src="pics/image3.jpeg" width="270" height="400px"/>

</html>
';
?>

<br>
<form method="get" action="seemore.php">
<div class="center">
    <button type="submit"><?php echo "See More"; ?></button></div>
</form>
<br> 


<?php echo "Go To Top : ";?>
<a href "index.php"><width="300" height="300px">Scroll Up</a>
<br>

</div>
</div>

<div class="footer">
  <h2></h2>
   <?php  
	echo "Contact Number : 1234567890";?>
<br>
<?php echo "Email I'd : jenise25@gmail.com ";?>
	
<form method="get" action="index.php">
<div class="center">
    <button type="submit"><?php echo "HOME"; ?></button></div>
</form>  
</div>

<script>
// Automatic Slideshow - change image every 3 seconds
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}
  x[myIndex-1].style.display = "block";
  setTimeout(carousel, 3000);
}
</script>

</body>
</html>