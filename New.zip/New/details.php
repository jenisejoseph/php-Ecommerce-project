   <html lang="en">
<?php require_once('ij.php'); ?>
<head>
<title>Mywebsite  <?php echo "Electronics"; ?></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>

/* Main column */
.main {   
  flex: 70%;
  background-color: #1abc9c;
  padding: 20px;
}
*{
	font-family: poppins;
}
body{
	margin: 0;
}
div.header{
	color: #f0f0f0;
	font-family: poppins;
	display: flex;
	flex-direction: row;
	align-items: center:
	justify-content:space-between;
	padding: 10px 90px;
	padding-top: 15px;
	background-color:#lclcle;
}
  div.header button{
	  background-color: #f0f0f0;
	  font-size: 16px;
	  font-weight:550;
	  padding: 8px 12px;
	  border: 2px solid black;
	  border-radius: 5px;
  }
}

</style>
</head>
<body>
 <div class="main">
 <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
 
 
    <h2>Business Information</h2>
    <br>
   <br>
   
   <h3>Overview : </h3> 
   <br>
   <br>
   <?php 
   
   echo "
Established in the year 2009,Chair sales and services in Beautiful Street,
 Pune is a top player in the category Furniture Dealers in the Pune.
 This well-known establishment acts as a one-stop destination servicing customers both local and from other parts of Pune.
 Over the course of its journey, this business has established a firm foothold in it’s industry.
 The belief that customer satisfaction is as important as their products and services,
 have helped this establishment garner a vast base of customers, which continues to grow by the day. 
 This business employs individuals that are dedicated towards their respective roles and put in a lot of effort
 to achieve the common vision and larger goals of the company. In the near future, this business aims to expand 
 its line of products and services and cater to a larger client base. In Pune, this establishment
 occupies a prominent location in Beautiful Street. It is an effortless task in commuting to this establishment as
 there are various modes of transport readily available. It is at ,
 ADDRESS : Beautiful Street side of Sun-city River,
	Pune-411015, Maharashtra, India, which makes it easy for first-time visitors in locating this establishment.";
 
 ?>
 
 <br>
 <br>
 <br>
 
 <h4>Products and Services offered :</h4>
 <?php 
 echo "
 
 Chair sales and services inBeatuiful Street has a wide range of products and services 
to cater to the varied requirements of their customers. <br>
It is known to provide top service in the following categories: 
<ol>
<li>Furniture Dealers</li>
<li> Wheel Chair Dealers</li>
<li> Chair Repair & Services </li>
<li> Office Chair Repair & Services </li>
<li> Wheel Chair Manufacturers </li>
<li> Office Chair Dealers </li>
<li> Chair Dealers </li>
<li> Revolving Chair Dealers.</li>
<br>
<br>
 The staff at this establishment are courteous and prompt at providing any assistance.
 They readily answer any queries or questions that you may have. 
Pay for the product or service with ease by using any of the available modes of payment, such as Cash, Cheques.


";
?> 

<br>
<br>
</body>
</html>