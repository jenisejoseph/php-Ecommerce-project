<?php

session_start();
  
include 'func.php';

$conn = db();

$user_id = $_POST['user_id'];

$first_name = $_POST['firstname'];

$last_name = $_POST['lastname'];

$email_id = $_POST['email'];

$password = $_POST['password'];

$address = $_POST['location'];

$date = $_POST['birthdate'];

$sql = "INSERT INTO users (user_id, firstname, lastname, email, password,location, birthday) VALUES 
('".$user_id."','".$first_name."', '".$last_name."', '".$email_id."', '".$password."', '".$address."', '".$date."')";

$query = $conn->query($sql);

// dd($query);

if ($query) 
{

	header('Location:index.php');

}


?>

