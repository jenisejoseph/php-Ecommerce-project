<?php 


header('Location:./New/index.php');



?>