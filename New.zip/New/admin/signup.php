<!DOCTYPE html>
<html>
	<head>
	<style>
	

.double {border-style: double;}

body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
  background-color: #labc9c;
}

/* Style the body */
.body {
  padding: 80px;
  background-color: #1abc9c;
  color: white;
   
}

/* Main column */
.container {   
    background-color: #1abc9c;
  
 
}

/* Increase the font size of the h1 element */
.header h1 {
  font-size: 40px;
}

/* Style the top navigation bar */
.navbar {
  overflow: hidden;
  background-color: #333;
}

/* Change color on hover */
.navbar a:hover {
  background-color: #ddd;
  color: black;
}
</style>

		<title>New Admin </title>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
</head>	
	<body>
		<br>
		<br>
		<br>
		<div class="container">
			<div class="col-md-6">
				<h1>New Admin</h1>
				<form action="signup-process.php" method="POST">
					<div class="form-group">
						<label for="exampleInputEmail1">name</label>
						<input type="text" class="form-control" placeholder="First Name" name="firstname">
					</div>
					
					<div class="form-group">
						<label for="exampleInputPassword1">email</label>
						<input type="text" class="form-control" placeholder="Email" name="email">
					</div>
					<div class="form-group">
						<label for="exampleInputPassword1">Password</label>
						<input type="password" class="form-control"  placeholder="Password" name="password">
					</div>
					
					<button type="submit" class="btn btn-default">Submit</button><br>
					<br>
					<br>
					<?php if (isset($_GET['err'])) {
							echo "Your username and password wrong";
						} ?>
				</form>
<br>
				
			</div>
		</div>
		
		 
		
		
	</body>
</html>