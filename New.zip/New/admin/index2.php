<!DOCTYPE html>
<html lang="en">
<body>
<?php require_once('navbar.php'); ?>
<?php require_once('sidebar.php'); ?>

</body>
</html>