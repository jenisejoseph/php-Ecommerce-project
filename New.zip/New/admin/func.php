<?php  

function dd($value)
{

	var_dump($value);

	die();

}


function db()
{

	$servername = "localhost";

	$username = "root";

	$password = "";

	$dbname = "blog";

	$conn = new mysqli ($servername, $username, $password, $dbname);

	if ($conn->connect_error) 
	{

		die("Connection failed".$conn->connect_error);
	

	}

	return $conn;

}

?>
