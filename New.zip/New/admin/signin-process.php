<?php 

session_start();

include 'func.php';

$conn = db();

$email = $_POST['email'];

$password = $_POST['password'];

$sql = " SELECT * FROM admin WHERE email = '".$email."' AND password = '".$password."' ";

$query = $conn->query($sql);

$result = $query->num_rows;

$name = $query->fetch_all(1)[0];

// dd($name);

if ($result>0) 
{
	
	if (isset($_POST['btn']) && $_POST['btn'] == 1) 
	{
	
		$_SESSION['email'] = $email;

		$_SESSION['name'] = $name['name'];

		$_SESSION['id'] = $name['id'];

		header('Location:dashbord.php');

	}
	else
	{

		$_SESSION['email'] = $email;	

		$_SESSION['name'] = $name['name'];

		$_SESSION['id'] = $name['id'];	

		header('Location:dashbord.php');

	}

}
else
{

	header('Location:login.php?err=1');

}



?>