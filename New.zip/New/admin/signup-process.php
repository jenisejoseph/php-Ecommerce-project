<?php

session_start();
  
include 'func.php';

$conn = db();

$id = $_POST['id'];

$name = $_POST['name'];

$email = $_POST['email'];

$password = $_POST['password'];

$is_active = $_POST['is_active'];

$sql = "INSERT INTO admin (id,name,email, password,is_active) VALUES 
('".$id."','".$name."', '".$email."', '".$password."', '".$is_active."')";

$query = $conn->query($sql);

// dd($query);

if ($query) 
{

	header('Location:login.php');

}


?>