 <!DOCTYPE html>
<html lang="en">
<head>
<title> <?php echo "ADMIN"; ?></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
/* {
  box-sizing: border-box;
}


/* Style the top navigation bar */
.navbar {
  overflow: hidden;
  background-color: #00FFFF;
}

/* Style the navigation bar links */
.navbar a {
  float: left;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 20px;
  text-decoration: none;
}

/* Right-aligned link */
.navbar a.right {
  float: right;
}

/* Change color on hover */
.navbar a:hover {
  background-color: #ddd;
  color: black;
}

.h1 {
	display: small;
	color: green;
	text-align:center;
	
}


/* Footer */
.footer {
  padding: 20px;
  text-align: center;
  background: #ddd;
}

/* Responsive layout - when the screen is less than 700px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 700px) {
  .row {   
    flex-direction: column;
  }
}

/* Responsive layout - when the screen is less than 400px wide, make the navigation links stack on top of each other instead of next to each other */
@media screen and (max-width: 400px) {
  .navbar a {
    float: none;
    width:100%;
  }
}

body{
	    font-family: "Montserrat-Bold";
		overflow:hidden;
    }

    #title{
      background-color: #fff;
      color: grey;
      margin-bottom: 1rem;
    }

    .logo{
      width:3rem;
      height: 3rem;
      border-radius:100%;
	  margin-left:40%;
    }

    .itemsushil{
      text-align: center;
      margin: 0 auto 0 auto;
    }

    .container2{
        background-color:black;
        margin-top: 20px;
        height:85vh;
        background-size:cover;
        background-position:center;
    }

    .rawlogo{
      margin-left: 1%;
	 
    }
	
	<link href="https://fonts.googleapis.com/css2?family=Anton&display=swap" rel="stylesheet">
	
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
	
	<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>

	
</style>
</head>
<body>
<div class="navbar">
 
  <h1><?php 
    echo ' WELCOME TO ADMIN  PANEL';?>
	 </h1>
 </div>
 <section id="title">
    <div class="container-fluid">
    <div class="navbar navbar-expand-lg navbar-light">
       <img class="logo" src="logo.jpg" alt="logo">
        <a class="navbar-brand rawlogo" href="">OFFICE CHAIRS</a>
         
       
    </div>
    </div>
 </section>
 
 
</body>
</html>