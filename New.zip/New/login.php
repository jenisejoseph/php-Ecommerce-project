<html>

	<head>
	<?php require_once('ab.php'); ?>
	<style>
	.double {border-style: double;}

body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
  background-color: #labc9c;
}

/* Style the body */
.body {
  padding: 80px;
  background-color: #1abc9c;
  color: white;
   text-align: center;
}

/* Main column */
.container {   
    background-color: #1abc9c;
  
 
}

.form-group {
	 text-align: center;
}
	



/* Style the top navigation bar */
.navbar {
  overflow: hidden;
  background-color: #333;
}

/* Change color on hover */
.navbar a:hover {
  background-color: #ddd;
  color: black;
}


</style>
</head>	
		<title>Login</title>
		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="ha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	
	<body>
	

	
	<nav class="navbar navbar-default">
    <div class="container-fluid">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
	
  
		<div class="container">
			<div class="col-md-6">
			<br>
			<form method="get" action="reg.php">
<div class="center">
    <button type="submit"><?php echo "DON'T HAVE AN ACCOUNT -> SIGN-UP"; ?></button></div>
</form> 
			
			
			
			    <h3>Sign In </h3>
				<br>
				<form class="form-horizontal" action="login-process.php" method="POST" >
					<div class="form-group">
						<label for="inputEmail3" class="col-sm-3 control-label">Email Id</label>
						<div class="col-sm-12">
							<input type="email" class="form-control" id="inputEmail3" placeholder="Email" name="email">
							<small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
						</div>
					</div>
					<br>
					<div class="form-group">
						<label for="inputPassword3" class="col-sm-3 control-label">Password</label>
						<div class="col-sm-12">
							<input type="password" class="form-control" id="inputPassword3" placeholder="Password" name="password">
							<small id="emailHelp" class="form-text text-muted">We'll never share your password with anyone else.</small>
						</div>
					</div>
					<br>
					 
					
					<div class="form-group">
						<div class="col-sm-offset-2 col-sm-10">
							<button type="submit" class="btn btn-default" name="btn">Sign in</button>
							<button type="reset" class="btn btn-default">Clear</button>
						</div>
						<br>
						<br>
						
						<?php if (isset($_GET['err'])) {
							echo "Your username and password wrong";
						} ?>
						<br>
						<br>
					</div>
				</form>
				
				<form method="get" action="signin.php">
<div class="left">
    <button type="submit"><?php echo "SIGN-IN AS ADMIN -> "; ?></button></div>
</form> 

			</div>
		</div>
		
		
		<br>
		<br>
		<br>
		<br>
		<br>
	</body>
</html>