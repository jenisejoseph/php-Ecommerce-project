<?php 
include("header.php")
?>
<!DOCTYPE html>
<html lang="en">
<head>
<style>
/* Style the top navigation bar */
.navbar {
  overflow: hidden;
  background-color: #333;
  height:50px;
}
 </style>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title>Index</title>
 </head>
 <body style="background-color:powderblue;">
     
	
	 
          <div class="container mt-5">
               <div class="row">
			   <div class="col-lg-3">
			   <form action="manage_cart.php" method="POST">
			   <div class="card">
			    <img src="pics/drafting/image0.jpeg" class="card-img-top">
	               <div class="card-body text-center">
	                  <h5 class="card-title">Ergonomic Drafting Chair,<br>Tall Desk Chair with Arms</h5>
	                     <p class="card-text">Price: Rs.1500</p>
	                       <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
			                 <input type="hidden" name="Item_Name" value="Ergonomic Drafting Chair,Tall Desk Chair with Arms">
				            <input type="hidden" name="Price" value="1500">
	                          </div>
							  </div>
							    </form>
								</div>
								
								 
	
	                            <div class="col-lg-3">
		                         <form action="manage_cart.php" method="POST">
	                                   <div class="card">
	                                   <img src="pics/drafting/image1.jpeg" class="card-img-top">
	                                         <div class="card-body text-center">
	                                         <h5 class="card-title">Home Office Adjustable Height,<br>Drafting Chair</h5>
	                                          <p class="card-text">Price: Rs.2000</p>
	                                          <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
			                                 <input type="hidden" name="Item_Name" value="Home Office Adjustable Height">
			                            	<input type="hidden" name="Price" value="2000">
	                                       </div>
										   </div>
 	                                      </form>
				                         </div>
	           
	  
			                       <div class="col-lg-3">
			                        <form action="manage_cart.php" method="POST">
	                                 <div class="card">
				                     <img src="pics/drafting/image2.jpeg" class="card-img-top">
	                                    <div class="card-body text-center">
	                                         <h5 class="card-title">Seating Apollo Drafting Stool, Black</h5>
	                                           <p class="card-text">Price: Rs.3750</p>
	                                                <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
			                                        <input type="hidden" name="Item_Name" value="Seating Apollo Drafting Stool, Black">
				                                      <input type="hidden" name="Price" value="3750">
	                                                  </div>
						                              </div>
			                                          </form>
										              </div>
				

                     		             <div class="col-lg-3"> 
			                                <form action="manage_cart.php" method="POST">
	                                        <div class="card">
				                               <img src="pics/drafting/image3.jpeg" class="card-img-top">
	                                             <div class="card-body text-center">
	                                              <h5 class="card-title">Desk Adjustable Drafting Stools with Backrest & Foot Rest</h5>
	                                              <p class="card-text">Price: Rs.3890</p>
	                                                   <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
			                                             <input type="hidden" name="Item_Name" value="Desk Adjustable Stools with Backrest
														 & Foot Rest">
				                                              <input type="hidden" name="Price" value="3890">
	                                                            </div>
						                                        </div>
			                                                      </form>
							                            			</div>		
										
										 <div class="col-lg-3">
			                        <form action="manage_cart.php" method="POST">
	                                 <div class="card">
				                     <img src="pics/drafting/image4.jpeg" class="card-img-top">
	                                    <div class="card-body text-center">
	                                         <h5 class="card-title">Adjustable Chrome Foot Ring,Drafting Adjustable Arms</h5>
	                                           <p class="card-text">Price: Rs.5000</p>
	                                                <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
			                                        <input type="hidden" name="Item_Name" value="Adjustable Chrome Foot Ring, Adjustable Arms">
				                                      <input type="hidden" name="Price" value="5000">
	                                                  </div>
						                              </div>
			                                          </form>
										              </div>
													  
											
										 <div class="col-lg-3">
			                        <form action="manage_cart.php" method="POST">
	                                 <div class="card">
				                     <img src="pics/drafting/image6.jpeg" class="card-img-top">
	                                    <div class="card-body text-center">
	                                         <h5 class="card-title">Shop Stool Chair,<br>Drafting chair</h5>
	                                           <p class="card-text">Price: Rs.8000</p>
	                                                <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
			                                        <input type="hidden" name="Item_Name" value="Shop Stool Chair">
				                                      <input type="hidden" name="Price" value="8000">
	                                                  </div>
						                              </div>
			                                          </form>
										              </div>		  
										 
										 <div class="col-lg-3">
			                        <form action="manage_cart.php" method="POST">
	                                 <div class="card">
				                     <img src="pics/drafting/image8.jpeg" class="card-img-top">
	                                    <div class="card-body text-center">
	                                         <h5 class="card-title">Office Desk<br> Drafting Chair</h5>
	                                           <p class="card-text">Price: Rs.4500</p>
	                                                <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
			                                        <input type="hidden" name="Item_Name" value="Office Desk Drafting Chair">
				                                      <input type="hidden" name="Price" value="4500">
	                                                  </div>
						                              </div>
			                                          </form>
										              </div>

                                           <div class="col-lg-3">
			                        <form action="manage_cart.php" method="POST">
	                                 <div class="card">
				                     <img src="pics/drafting/image9.jpeg" class="card-img-top">
	                                    <div class="card-body text-center">
	                                         <h5 class="card-title">Office Desk Drafting Chair with Foot Rest (Black)</h5>
	                                           <p class="card-text">Price: Rs.3000</p>
	                                                <button type="submit" name="Add_To_Cart" class="btn btn-info">Add To Cart</button>
			                                        <input type="hidden" name="Item_Name" value="Office Desk Drafting Chair with Foot Rest (Black)">
				                                      <input type="hidden" name="Price" value="3000">
	                                                  </div>
						                              </div>
			                                          </form>
										              </div>	

													  
	
		    </div>
          </div>
        </div>
		<div class="navbar">

  <a href="drafting1.php"><width="300" height="300px">SCROLL UP</a>
 
 </div>
      </body>
   </html>
   