<?php error_reporting(E_ALL); ?>
<?php 
       ini_set("display_errors",1);
       error_reporting(E_ALL);
        //code goes here
?>
<?php
session_start();
  
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "blog";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
//echo "connected";
// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
//echo " not connected";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Panel</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css">
<style>
*{
	font-family: poppins;
}
body{
	margin: 0;
}
div.header{
	color: #f0f0f0;
	font-family: poppins;
	display: flex;
	flex-direction: row;
	align-items: center:
	justify-content:space-between;
	padding: 10px 90px;
	padding-top: 15px;
	background-color:#lclcle;
}
  div.header button{
	  background-color: #f0f0f0;
	  font-size: 16px;
	  font-weight:550;
	  padding: 8px 12px;
	  border: 2px solid black;
	  border-radius: 5px;
  }
}

</style>
</head>
<body>

<div class="header">
<h1>ADMIN PANEL </h1> <br><br>
<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
<button type="submit" name="dashbord" formaction="dashbord.php">DASHBOARD</button>
<button type="submit" name="userinfo" formaction="userinfo.php">USERS</button>
<button type="submit" name="logout" formaction="logout.php">LOGOUT</button>


</form>
</div>

<div class="container">
    <div class="row">
       <div class="col-lg-12">
 <table class="table text-center table-dark">
  <thead>
    <tr>
	<th scope="col">Order ID</th>
	<th scope="col">Customer Name</th>
    <th scope="col">Phone No</th>
	<th scope="col">Address</th>
	<th scope="col">Pay Mode</th>
	<th scope="col">Orders</th>
	</tr>
    </thead>
  <tbody>
  <?php
 // $query="SELECT * FROM 'order_manager'";
 $query = "SELECT * FROM `order_manager`";
  $user_result=mysqli_query($conn,$query);
  while($user_fetch=mysqli_fetch_assoc($user_result))
  
  {
	  echo"
	  <tr>
    <td>$user_fetch[Order_id]</td>
     <td>$user_fetch[Full_Name]</td>
    <td>$user_fetch[Phone_No]</td>
    <td>$user_fetch[Address]</td>
	 <td>$user_fetch[Pay_Mode]</td>
	<td>
	<table class='table text-center table-dark'>
  <thead>
    <tr>
	<th scope='col'>Item Name</th>
	<th scope='col'>Price</th>
    <th scope='col'>Quantity</th>
	</tr>
    </thead>
  <tbody>
";

	//$order_query="SELECT * FROM 'user_order' WHERE 'Order_id'='$user_fetch[Order_id]'";
	//$order_query="SELECT `Order_id`, `Item_Name`, `Price`, `Quantity` FROM `user_order` 
	//WHERE 'Order_id'='$user_fetch[Order_id]'";
	$order_query="SELECT * FROM user_order WHERE Order_id=$user_fetch[Order_id]";
	//$order_query = "SELECT * FROM `user_order` WHERE 'user_order'='Order_id' = 'order_manager'='Order_id'";
       
	$order_result=mysqli_query($conn,$order_query);
	while($order_fetch=mysqli_fetch_assoc($order_result))
	{
		echo"
		<tr>
		<td>$order_fetch[Item_Name]</td>
		<td>$order_fetch[Price]</td>
		<td>$order_fetch[Quantity]</td>
		</tr>
      ";
	}
	
	
	echo"
	</tbody>
	
	</table>
    </td>
    </tr>
   ";
  }
  
  ?>
  
   
  </tbody>
</table>
</div>
</div>
</div>

<?php 
if(isset($_POST['Logout']))
{
	session_destroy();
	header("location: index.php");
}
?>


</body>
</html>