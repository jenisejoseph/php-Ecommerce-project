<?php
session_start();
  
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "blog";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

?>


<!DOCTYPE html>
<html lang="en">
<?php require_once('popup.php'); ?>
<head>
<title>Mywebsite  <?php echo "Electronics"; ?></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
/* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
  margin: 0;
}

/* Style the header */
.header {
  padding: 80px;
  text-align: center;
  background: #1abc9c;
  color: white;
   
}

/* Increase the font size of the h1 element */
.header h1 {
  font-size: 40px;
}

/* Style the top navigation bar */
.navbar {
  overflow: hidden;
  background-color: #333;
}

/* Style the navigation bar links */
.navbar a {
  float: left;
  display: block;
  color: white;
  text-align: center;
  padding: 14px 20px;
  text-decoration: none;
}

/* Right-aligned link */
.navbar a.right {
  float: right;
}

/* Change color on hover */
.navbar a:hover {
  background-color: #ddd;
  color: black;
}

/* Column container */
.row {  
  display: flex;
  flex-wrap: wrap;
}

/* Create two unequal columns that sits next to each other */
/* Sidebar/left column */
.side {
  flex: 30%;
  background-color: #f1f1f1;
  padding: 20px;

  }

/* Main column */
.main {   
  flex: 70%;
  background-color: white;
  padding: 20px;
}

/* Fake image, just for this example */
.fakeimg {
  background-color: #aaa;
  width: 100%;
  padding: 20px;
}

.center {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 90px;
  border: white; 
}

.mybtn {
  display: none; /* Hidden by default */
  position: fixed; /* Fixed/sticky position */
  bottom: 20px; /* Place the button at the bottom of the page */
  right: 30px; /* Place the button 30px from the right */
  z-index: 99; /* Make sure it does not overlap */
  border: none; /* Remove borders */
  outline: none; /* Remove outline */
  background-color: red; /* Set a background color */
  color: white; /* Text color */
  cursor: pointer; /* Add a mouse pointer on hover */
  padding: 15px; /* Some padding */
  border-radius: 10px; /* Rounded corners */
  font-size: 18px; /* Increase font size */
}

.mybtn:hover {
  background-color: #555; /* Add a dark-grey background on hover */
}


/* Footer */
.footer {
  padding: 20px;
  text-align: center;
  background: #ddd;
}

/* Responsive layout - when the screen is less than 700px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 700px) {
  .row {   
    flex-direction: column;
  }
}

/* Responsive layout - when the screen is less than 400px wide, make the navigation links stack on top of each other instead of next to each other */
@media screen and (max-width: 400px) {
  .navbar a {
    float: none;
    width:100%;
  }
}
.dropdown {
  float: left;
  overflow: hidden;
}
.dropdown .dropbtn {
  font-size: 16px;  
  border: none;
  outline: none;
  color: white;
  padding: 14px 16px;
  background-color: inherit;
  font-family: inherit;
  margin: 0;
 
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #333;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
 
}

.dropdown-content a {
  float: none;
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  background-color: #ddd;
}

.dropdown:hover .dropdown-content {
  display: block;
}

.h1 {
  float: right;
  display: block;
  color: green;
  text-align:center;
  padding: 14px 20px;
  text-decoration: none;
  
}

.container{
	max-width:1200px;
	margin:auto;
	background:#ddd;
	overflow:auto;
}
.gallery{
	margin:14px;
	border:1px solid #ccc;
	float:left;
	width:290px;
}
.gallery img{
	width:70%;
	height:auto;
}
.desc{
	padding:12px;
	test-align:center;
}

</style>
</head>
<body>

<div class="navbar">
  <a href="#">HOME</a>
  <a href="details.php">ABOUT-US</a>
  <a href="contact.php">CONTACT</a>

  <a href="logout.php" class="right">Logout</a>
 
</div>
<div class="header">
  <h1>Office Chairs</h1>
  <p>A website created by me.</p>
</div>

<div class="navbar">
   <div class="dropdown" style="width:70px;">
    <button class="dropbtn" align="left">Products
      <i class="fa fa-caret-down"></i></a>
    </button> 
    <div class="dropdown-content">
      <a href="drafting/drafting1.php">Drafting Chairs</a><a href="executive/executive1.php">Executive Chairs</a><br>
      <a href="leather/leather1.php">Leather Chairs</a><a href="mesh/mesh1.php">Mesh Chairs</a><br>
      <a href="big/big1.php">Big and Tall Chairs</a><a href="small/small1.php">Petite and Small Chairs</a><br>
	  <a href="24hr/24hr1.php">24-hr Office Chair</a><a href="confe/confe1.php"> Conference Chair</a>
    </div>
  </div> 


 <div class="dropdown">
    <button class="dropbtn" style="width:40%" align="right">New Release Products
      <i class="fa fa-caret-down"></i></a>
    </button>
   <div class="dropdown-content">
      <a href="drafting/drafting1.php">Drafting Chairs</a><a href="executive/executive1.php">Executive Chairs</a><br>
      <a href="leather/leather1.php">Leather Chairs</a>
	  </div>
	  
	  
	  </div>
	
</div>


<h1> DRAFTING CHAIRS </h1>

<?php
echo'
<div class ="container">
<div class ="gallery">
<img src="pics/drafting/image0.jpeg" >
<div class ="desc"> 
<a href="drafting/drafting1.php">FOR MORE DETAILS </a></div>
</div>

<div class ="gallery">
<img src="pics/drafting/image1.jpeg">
<div class ="desc">
<a href="drafting/drafting1.php">FOR MORE DETAILS </a></div>
</div>

<div class ="gallery">
<img src="pics/drafting/image2.jpeg">
<div class ="desc"> 
<a href="drafting/drafting1.php">FOR MORE DETAILS </a></div>
</div>
';
?>

<br>
<br>

<h1> EXECUTIVE CHAIRS </h1>

<?php
echo'
<div class ="container">
<div class ="gallery">
<img src="pics/executive/image17.jpeg" >
<div class ="desc"> 
<a href="executive/executive1.php">FOR MORE DETAILS </a></div>
</div>

<div class ="gallery">
<img src="pics/executive/image20.jpeg">
<div class ="desc"> 
<a href="executive/executive1.php">FOR MORE DETAILS </a></div>
</div>


<div class ="gallery">
<img src="pics/executive/image21.jpeg">
<div class ="desc"> 
<a href="executive/executive1.php">FOR MORE DETAILS </a></div>
</div>
</div>
';
?>

<h1> LEATHER CHAIRS </h1>

<?php
echo'
<div class ="container">
<div class ="gallery">
<img src="pics/leather/image15.jpeg" >
<div class ="desc"> 
<a href="leather/leather1.php">FOR MORE DETAILS </a></div>
</div>

<div class ="gallery">
<img src="pics/leather/image16.jpeg">
<div class ="desc"> 
<a href="leather/leather1.php">FOR MORE DETAILS </a></div></div>


<div class ="gallery">
<img src="pics/leather/image15.jpeg">
<div class ="desc"> 
<a href="leather/leather1.php">FOR MORE DETAILS </a></div>
</div>

</div>

';
?>

<h1> MESH CHAIRS </h1>

<?php
echo'
<div class ="container">
<div class ="gallery">
<img src="pics/mesh/image35.jpeg" >
<div class ="desc"> 
<a href="mesh/mesh1.php">FOR MORE DETAILS </a></div>
</div>

<div class ="gallery">
<img src="pics/mesh/image5.jpeg">
<div class ="desc"> 
<a href="mesh/mesh1.php">FOR MORE DETAILS </a></div>
</div>


<div class ="gallery">
<img src="pics/mesh/image36.jpeg">
<div class ="desc"> 
<a href="mesh/mesh1.php">FOR MORE DETAILS </a></div></div>

</div>
';
?>

<h1>Big and Tall Chairs</h1>

<?php
echo'
<div class ="container">
<div class ="gallery">
<img src="pics/big/image13.jpeg" >
<div class ="desc"> 
<a href="big/big1.php">FOR MORE DETAILS </a></div>
</div>

<div class ="gallery">
<img src="pics/big/image14.jpeg">
<div class ="desc"> 
<a href="big/big1.php">FOR MORE DETAILS </a></div></div>


<div class ="gallery">
<img src="pics/big/image30.jpeg">
<div class ="desc"> 
<a href="big/big1.php">FOR MORE DETAILS </a></div></div>

</div>

';
?>

<h1>Petite and Small Chairs</h1>
<?php
echo'
<div class ="container">
<div class ="gallery">
<img src="pics/small/image11.jpeg" >
<div class ="desc"> 
<a href="small/small1.php">FOR MORE DETAILS </a></div></div>

<div class ="gallery">
<img src="pics/small/image31.jpeg">
<div class ="desc"> 
<a href="small/small1.php">FOR MORE DETAILS </a></div></div>


<div class ="gallery">
<img src="pics/small/image34.jpeg">
<div class ="desc"> 
<a href="small/small1.php">FOR MORE DETAILS </a></div></div>

</div>

';
?>

<h1>24-hr Office Chairs</h1>
<?php
echo'
<div class ="container">
<div class ="gallery">
<img src="pics/24hr/image12.jpeg" >
<div class ="desc"> 
<a href="24hr/24hr1.php">FOR MORE DETAILS </a></div></div>

<div class ="gallery">
<img src="pics/24hr/image18.jpeg">
<div class ="desc"> 
<a href="24hr/24hr1.php">FOR MORE DETAILS </a></div></div>


<div class ="gallery">
<img src="pics/24hr/image32.jpeg">
<div class ="desc"> 
<a href="24hr/24hr1.php">FOR MORE DETAILS </a></div></div>

</div>

';
?>

<h1>Conference Chairs</h1>
<?php
echo'
<div class ="container">
<div class ="gallery">
<img src="pics/conf/image24.jpeg" >
<div class ="desc"> 
<a href="confe/confe1.php">FOR MORE DETAILS </a></div></div>

<div class ="gallery">
<img src="pics/conf/image26.jpeg">
<div class ="desc"> 
<a href="confe/confe1.php">FOR MORE DETAILS </a></div></div>


<div class ="gallery">
<img src="pics/conf/image28.jpeg">
<div class ="desc"> 
<a href="confe/confe1.php">FOR MORE DETAILS </a></div></div>

</div>

';
?>




<?php require_once('footer.php'); ?>


</body>
</html>