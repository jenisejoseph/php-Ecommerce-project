<html>
<style>
/* Change color on hover */
.navbar a:hover {
  background-color: #ddd;
  color: black;
}

/* Column container */
.row {  
  display: flex;
  flex-wrap: wrap;
}


  
  .mybtn {
  display: none; /* Hidden by default */
  position: fixed; /* Fixed/sticky position */
  bottom: 20px; /* Place the button at the bottom of the page */
  right: 30px; /* Place the button 30px from the right */
  z-index: 99; /* Make sure it does not overlap */
  border: none; /* Remove borders */
  outline: none; /* Remove outline */
  background-color: red; /* Set a background color */
  color: white; /* Text color */
  cursor: pointer; /* Add a mouse pointer on hover */
  padding: 15px; /* Some padding */
  border-radius: 10px; /* Rounded corners */
  font-size: 18px; /* Increase font size */
}

.mybtn:hover {
  background-color: #555; /* Add a dark-grey background on hover */
}
/* Responsive layout - when the screen is less than 700px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 700px) {
  .row {   
    flex-direction: column;
  }
}

/* Responsive layout - when the screen is less than 400px wide, make the navigation links stack on top of each other instead of next to each other */
@media screen and (max-width: 400px) {
  .navbar a {
    float: none;
    width:100%;
  }
}
/* Fake image, just for this example */
.fakeimg {
  background-color: #aaa;
  width: 100%;
  padding: 20px;
}
/* Main column */
.main {   
  flex: 90%;
  background-color: blue;
  padding: 70px;
}
  </style>


<?php 
//session_start();  
//if (!isset($_SESSION['email'])) {
  //header("location:signin.php");
//}

?>
 
<?php include "navbar.php"; ?>

<div class="row">
  <div class="side" style="height:400px;">
    <h2>Index</h2>
	
    <div class="sidebar-sticky" style="height:400px,weight:200px;">
	<ul class="nav flex-column">
	  <!-- Slide Show -->
<section>

          <?php 


            $uri = $_SERVER['REQUEST_URI']; 
            $uriAr = explode("/", $uri);
            $page = end($uriAr);

          ?>


          <li class="nav-item">
            <a class="fakeimg <?php echo ($page == '' || $page == 'index.php') ? 'active' : ''; ?>" href="index.php">
              <span data-feather="home"></span>
              Dashboard <span class="sr-only">(current)</span>
            </a>
          </li>
		  <br>
		  <br>
		  <br>
          <li class="nav-item">
            <a class="fakeimg <?php echo ($page == 'customer_orders.php') ? 'active' : ''; ?>" href="customer_orders.php">
              <span data-feather="file"></span>
              Orders
            </a>
          </li>
		  <br>
		  <br>
		  <br>
          <li class="nav-item">
            <a class="fakeimg <?php echo ($page == 'products.php') ? 'active' : ''; ?>" href="products.php">
              <span data-feather="shopping-cart"></span>
              Products
            </a>
          </li>
          <br>
		  <br>
		  <br>
          <li class="nav-item">
            <a class="fakeimg <?php echo ($page == 'categories.php') ? 'active' : ''; ?>" href="categories.php">
              <span data-feather="shopping-cart"></span>
              Categories
            </a>
          </li>
		  <br>
		  <br>
		  <br>
          <li class="nav-item">
            <a class="fakeimg <?php echo ($page == 'customers.php') ? 'active' : ''; ?>" href="customers.php">
              <span data-feather="users"></span>
              Customers
            </a>
          </li>
        </ul>
<br>
		  <br>
		  <br>
       
      </div>
    </nav>
</section>
</div>

    <main role="main" class="col-md-20 ml-sm-auto col-lg-80 px-4">
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Hello <?php echo "Admin"; ?></h1>
        </main>
      </div>

<?php //include "sidebar.php"; ?>

<div class="container-fluid">
  <div class="row">
    
    <?php //include "./templates/sidebar.php"; ?>

      <!-- <canvas class="my-4 w-100" id="myChart" width="900" height="380"></canvas> -->

      <h2>Other Admins</h2>
      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th>#</th>
              <th>Name</th>
              <th>Email</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody id="admin_list">
            <tr>
              <td>1,001</td>
              <td>Lorem</td>
              <td>ipsum</td>
              <td>dolor</td>
              <td>sit</td>
            </tr>
          </tbody>
        </table>
      </div>
    </main>
  </div>
</div>

<?php include "footer.php"; ?>
</html>